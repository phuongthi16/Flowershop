<link rel="stylesheet" type="text/css" href="css/style-main.css">

<div class="main-row">
	<div class="col-lg-8">
		<div class="main-title1">
			<h1> Sản phẩm bán chạy</h1>
		</div>
		<div class="list">
			
		</div>
	</div>
	<div class="col-lg-4">
		<div class="main-title2">
			<h1> Tìm kiếm</h1>
		</div>
	</div>
</div>