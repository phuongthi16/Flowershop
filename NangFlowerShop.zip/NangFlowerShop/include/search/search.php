<div class="box">
	<input type="text" placeholder="Nhập sản phẩm tìm kiếm tại đây">
	<a><i class="glyphicon glyphicon-search"></i></a>
</div>
<div class="row row2">
	<div class="col-sm-3">
		<h1>free ship</h1>
		<h2>Nội thành TP Đà Lạt</h2>
	</div>
	<div class="col-sm-3">
		<h1>giảm ngay</h1>
		<h2>Khi mua từ 2 sản phẩm</h2>
	</div>
	<div class="col-sm-3">
		<h1>Tặng kèm</h1>
		<h2>Phụ kiện trang trí</h2>
	</div>
	<div class="col-sm-3">
		<h1>Cam kết</h1>
		<h2>Khách hàng hài lòng 100%</h2>
	</div>
</div>